import { Module } from '@nestjs/common';
import { ThLogLevel, ThTracingModule } from 'themis';

import { HelloModule } from './modules/hello/hello.module';
import { envs } from './config/envs.config';

@Module({
  imports: [
    HelloModule,
    ThTracingModule.registerLoggerAsync({
      inject: [],
      useFactory: () => ({
        environment: envs.env,
        service: envs.service,
        version: envs.version,
        minimumLevel: envs.minLevel as ThLogLevel,
        format: {
          pretty: envs.logsProperties,
          colors: envs.logsColors
        }
      })
    })
  ]
})
export class AppModule {}
