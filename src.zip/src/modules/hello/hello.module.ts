import { Module } from '@nestjs/common';

import { TOKENS } from '~/shared/constants/tokens.constant';

import { GreetingUseCase } from './application/use-cases/greeting.use-case';

import { HelloRepository } from './infrastructure/persistence/hello-repository.adapter';
import { HelloService } from './domain/services/hello.service';
import { AwsSnsProvider } from './infrastructure/providers/aws-sns.adapter';
import { KafkaProducerAdapter } from './infrastructure/events/kafka-producer.adapter';
import { KafkaConsumerAdapter } from './infrastructure/events/kafka-consumer.adapter';
import { HelloController } from './entrypoints/http/controllers/hello.controller';

@Module({
  imports: [],
  controllers: [HelloController],

  providers: [
    GreetingUseCase,
    { provide: TOKENS.HELLO_REPOSITORY, useClass: HelloRepository },
    { provide: TOKENS.HELLO_SERVICE, useClass: HelloService },
    { provide: TOKENS.HELLO_PROVIDER, useClass: AwsSnsProvider },
    { provide: TOKENS.EVENTS_PRODUCER, useClass: KafkaProducerAdapter },
    { provide: TOKENS.EVENTS_CONSUMER, useClass: KafkaConsumerAdapter }
  ],
  exports: []
})
export class HelloModule {}
