import { Logger } from '@nestjs/common';
import { IHelloProvider } from '../../application/ports/outbound/providers/ hello-provider.port';



export class AwsSnsProvider implements IHelloProvider {
  private readonly logger = new Logger(AwsSnsProvider.name);
  sendSMS(): void {
    this.logger.log('Sending SMS using AWS SNS...');
  }
}
