import { IHelloProducer } from '../../application/ports';

export class KafkaProducerAdapter implements IHelloProducer<unknown> {
  send(__: unknown): void {
    // Implementation for sending Kafka events
  }
}
