import { IEventConsumer } from '../../application/ports';

// Aqui va el servicio de kafka de la libreria de themis
export class KafkaConsumerAdapter implements IEventConsumer {
  subscribe(__: (event: unknown) => void, ___: (raw: unknown) => void): void {
    // Implementation for subscribing to Kafka events
  }

  ack(__: unknown): void {
    // Implementation for acknowledging Kafka events
  }
}
