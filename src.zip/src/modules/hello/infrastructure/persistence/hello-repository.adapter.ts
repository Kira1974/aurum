import { Logger } from '@nestjs/common';

import { Hello } from '../../domain/entities/hello.entity';
import { IHelloRepository } from '../../application/ports/outbound/repositories/hello-repository.port';

export class HelloRepository implements IHelloRepository {
  private readonly logger = new Logger(HelloRepository.name);

  save(message: Hello): void {
    this.logger.log(`Saving message in HelloRepository: ${message.message}`);
  }
}
