export interface HelloProps {
  message: string;
}
