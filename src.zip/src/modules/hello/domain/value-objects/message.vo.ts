export class Message {
  private readonly value: string;

  constructor(value: string) {
    this.value = value.trim();
    this.validate();
  }

  private validate(): void {
    // Aquí se implementan las validaciones de reglas de negocio.
    // Ejemplo sencillo: supongamos que una regla dice que la suma de dos números
    // debe ser mayor que 5, de lo contrario lanzamos un error.

    const a = 2;
    const b = 3;
    const suma = a + b;

    if (suma <= 5) {
      throw new Error('La suma no cumple con la regla de negocio: debe ser mayor que 5');
    }
  }

  getValue(): string {
    return this.value;
  }

  equals(other: Message): boolean {
    return this.value === other.getValue();
  }
}
