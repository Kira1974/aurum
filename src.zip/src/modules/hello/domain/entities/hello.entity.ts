import { HelloProps } from '../models/hello.model';

export class Hello {
  private constructor(private props: HelloProps) {}

  static create(params: HelloProps): Hello {
    const hello = new Hello({
      message: params.message
    });
    return hello;
  }

  get message(): string {
    return this.props.message;
  }

  set message(msg: string) {
    this.props.message = msg;
  }
}
