import { Inject, Logger } from '@nestjs/common';
import { ThStandardResponse } from 'themis';

import { TOKENS } from '~/shared/constants/tokens.constant';


import { Hello } from '../entities/hello.entity';
import { IHelloService } from '../../application/services/hello-service.interface';
import { IHelloRepository } from '../../application/ports/outbound/repositories/hello-repository.port';
import { IHelloProducer } from '../../application/ports';

export class HelloService implements IHelloService {
  private readonly logger = new Logger(HelloService.name);

  constructor(
    @Inject(TOKENS.HELLO_REPOSITORY) private readonly helloRepository: IHelloRepository,
    @Inject(TOKENS.EVENTS_PRODUCER) private readonly eventProducer: IHelloProducer<string>
  ) {}

  async greeting(message: string): Promise<ThStandardResponse<string>> {
    this.logger.log(`Greeting created with message in HelloService: ${message}`);

    const hello: Hello = Hello.create({ message });
    this.helloRepository.save(hello);

    this.eventProducer.send(`Event from HelloService with message: ${message}`);

    return Promise.resolve({
      code: 100,
      message: 'Exitoso',
      data: `Hello, ${hello.message}!`
    });
  }
}
