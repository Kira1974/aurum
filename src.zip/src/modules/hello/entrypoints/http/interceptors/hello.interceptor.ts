import { CallHandler, ExecutionContext, Injectable, Logger, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';

@Injectable()
export class HelloInterceptor implements NestInterceptor {
  private readonly logger = new Logger(HelloInterceptor.name);
  intercept(__: ExecutionContext, next: CallHandler): Observable<any> {
    this.logger.log('Hello from interceptor');
    return next.handle();
  }
}
