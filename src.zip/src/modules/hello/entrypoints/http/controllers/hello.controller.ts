import { Body, Controller, Inject, OnModuleInit, Post, UseInterceptors } from '@nestjs/common';
import { ThLogger, ThLoggerService, ThStandardResponse } from 'themis';
import { CreateHelloDto } from '~/modules/hello/application/dto/hello.dto';
import { IEventConsumer, IHelloProducer } from '~/modules/hello/application/ports';
import { GreetingUseCase } from '~/modules/hello/application/use-cases/greeting.use-case';

import { HelloInterceptor } from '~/modules/hello/entrypoints/http/interceptors/hello.interceptor';
import { TOKENS } from '~/shared/constants/tokens.constant';


@Controller('hello')
@UseInterceptors(HelloInterceptor)
export class HelloController implements OnModuleInit {
  private readonly logger: ThLogger;

  constructor(
    private readonly helloUseCase: GreetingUseCase,
    @Inject(TOKENS.EVENTS_PRODUCER) private readonly eventProducer: IHelloProducer<string>,
    @Inject(TOKENS.EVENTS_CONSUMER) private readonly eventConsumer: IEventConsumer,
    private readonly loggerService: ThLoggerService
  ) {
    this.logger = this.loggerService.getLogger(HelloController.name);
  }

  onModuleInit(): void {
    this.eventConsumer.subscribe(
      (event: undefined) => {
        this.logger.log('Consumed event:', event);
        this.eventConsumer.ack(event);
      },
      (raw: undefined) => {
        this.logger.log('Parsed raw event:', raw);
      }
    );
  }

  @Post('world')
  async hello(@Body() dto: CreateHelloDto): Promise<ThStandardResponse<string>> {
    this.eventProducer.send('Hello event from controller');
    this.logger.log('Received hello request with message:', dto);
    return await this.helloUseCase.execute(dto);
  }
}
