
import { ThStandardResponse } from 'themis';
export interface IHelloService {
  greeting(message: string): Promise<ThStandardResponse<string>>;
}