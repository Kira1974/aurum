export interface IHelloProvider {
  sendSMS(): void;
}
