import { HelloProps } from '../../../../domain/models/hello.model';

export interface IHelloRepository {
  save(helloProps: HelloProps): void;
}
