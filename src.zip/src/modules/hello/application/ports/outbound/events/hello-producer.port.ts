export interface IHelloProducer<T> {
  send(record: T): void;
}
