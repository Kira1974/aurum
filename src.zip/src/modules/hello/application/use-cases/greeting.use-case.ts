import { Inject, Injectable } from '@nestjs/common';
import { ThLogger, ThLoggerService, ThStandardResponse } from 'themis';

import { TOKENS } from '~/shared/constants/tokens.constant';

import { CreateHelloDto } from '../dto/hello.dto';
import { IHelloService } from '../services/hello-service.interface';
import { IHelloProvider } from '../ports/outbound/providers/ hello-provider.port';

@Injectable()
export class GreetingUseCase {
  private readonly logger: ThLogger;

  constructor(
    @Inject(TOKENS.HELLO_SERVICE) private readonly helloService: IHelloService,
    @Inject(TOKENS.HELLO_PROVIDER) private readonly helloProvider: IHelloProvider,
    private readonly loggerService: ThLoggerService
  ) {
    this.logger = this.loggerService.getLogger(GreetingUseCase.name);
  }

  async execute(input: CreateHelloDto): Promise<ThStandardResponse<string>> {
    const { message } = input;

    // const messageVo = new Message(message); // ✅ Valida y asegura reglas del dominio (Value Objects)

    this.logger.warn('Executing hello use case with message: ', input);
    this.helloProvider.sendSMS();

    return await this.helloService.greeting(message);
  }
}
