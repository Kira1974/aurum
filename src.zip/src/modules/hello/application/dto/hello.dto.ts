import { IsNotEmpty } from 'class-validator';

export class CreateHelloDto {
  @IsNotEmpty()
  message: string;
}
